import unittest
import super_algos

class MyTestCase(unittest.TestCase):

    def test_find_min(self):
        my_List = [4,3,'A',5]
        empty_list = []
        my_List2 = [4,3,2,5]
        
        self.assertEqual(super_algos.find_min(my_List), -1)
        self.assertEqual(super_algos.find_min(empty_list), -1)
        self.assertEqual(super_algos.find_min(my_List2), 2)
    
    def test_sum_all(self):
        test_list = [1,2,3,'s',5]
        empty_list = []
        test_list2 = [1,2,3,4,5]

        self.assertEqual(super_algos.sum_all(test_list), -1)
        self.assertEqual(super_algos.find_min(empty_list), -1)
        self.assertEqual(super_algos.sum_all(test_list2), 15)

    def test_find_possible_strings(self):
        k = 2
        x = 3
        y = 2
        set1 = {'a', 'b'}
        set2 = {'x', 'y'}
        set3 = {1, 2}
        self.assertEqual(super_algos.find_possible_strings(set1, k), ['aa','ab', 'ba', 'bb'])
        self.assertEqual(super_algos.find_possible_strings(set2, x), ['xxx','xxy', 'xyx', 'xyy', 'yxx', 'yxy', 'yyx', 'yyy'])
        self.assertEqual(super_algos.find_possible_strings(set3, y), [])

if __name__ == "__main__":
    unittest.main()
