
def find_min(element):
    """TODO: complete for Step 1"""
    if (element == []) or (isinstance(element[0], int) == False):
        return (-1)

    second_Smallest = element[0]
    if (len(element) > 1):
        smallest = find_min(element[1:])

        if (second_Smallest < smallest):
            return second_Smallest
        elif (smallest < second_Smallest):
            return smallest
        elif (smallest == second_Smallest):
            return (smallest)
    elif (len(element) == 1):
        return (element[0])


def sum_all(element):
    """TODO: complete for Step 2"""

    for i in range(len(element)):
        if (isinstance(element[i], int) == False):
            return (-1)
    
    if (element == []):
        return (-1)
    elif (len(element) == 1):
        return (element[0])
    else:
        element[0] = element[0] + element[1]
        element.pop(1)
        return sum_all(element)

def find_possible_strings(character_set, k):
    """TODO: complete for Step 3"""
    if (character_set != [] and k != 1):
        combo_list = []
        n = len(character_set)          #length of the list
        char_list = list(character_set)
        for i in range(len(char_list)):
            if (isinstance(char_list[i], str) == False):        #if one of the items in char_list are not a string, return an empty list
                return ([])
            else:
                continue
        char_list.sort()
        return (find_possible_strings_rec(char_list, '', n, k, combo_list))
    elif (k == 1):
        char_list = list(character_set)
        char_list.sort()
        return (char_list)
    else:

        return ([])

def find_possible_strings_rec(char_list, prefix, n, k,  combo_list):
    """
        The main recursive method
        to return all possible
        strings of lenght k
    """
    if (k == 0):                                            #Base case: if k is 0, return prefix
        return (combo_list)

    for i in range(n):
        newPrefix = prefix + char_list[i]
        if (len(newPrefix) > k):
            combo_list.append(newPrefix)
        find_possible_strings_rec(char_list, newPrefix, n, k - 1, combo_list)
    return (combo_list)    
            
            
    
if __name__ == "__main__":
    
    print(find_min([4,3,'a',5]))
    print(sum_all([100,101,-5]))
    set1 = {"a", "b"}
    k = 4
    print(find_possible_strings(set1, k))
