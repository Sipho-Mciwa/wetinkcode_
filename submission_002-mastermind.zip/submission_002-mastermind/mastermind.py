import random
def get_Code():
    code = []
    while (len(code) < 4):
        ran_Num = random.randint(1, 9)
        if ran_Num not in code:
            code.append(ran_Num)
    return (code)

def get_User_Input():
    
    len_check = input("Input 4 digit code: ")
    if (len(len_check) != 4) or (len_check.isdigit() == False) or (len_check >= '0' or len_check <= '9'):
        print("Please enter exactly 4 digits.")
        return get_User_Input()
    else:
        user_Input = eval(len_check)
        counter = 1000
        code_breaker = []
        for i in range(4):
            code_breaker.append(user_Input // counter)
            user_Input = user_Input % counter
            counter = counter // 10
        return code_breaker

def code_Master(code, code_breaker):
    correct = 0
    incorrect = 0
    if (code_breaker == code):
        i = 0
        while(i < len(code)):
            if code_breaker[i] in code:
                index_1 = code.index(code_breaker[i])           #getting index in CPU generated list
                index_2 = code_breaker.index(code_breaker[i])   #getting index from user generated list
                if index_1 == index_2:
                    correct += 1
                else:
                    incorrect += 1      
            else:
                pass
            i += 1   
        print("Number of correct digits in correct place:    ", correct)
        print("Number of correct digits not in correct place:", incorrect)
        return True
    else:
        k = 0
        while(k < len(code)):
            if code_breaker[k] in code:
                index_1 = code.index(code_breaker[k])           #getting index in CPU generated list
                index_2 = code_breaker.index(code_breaker[k])   #getting index from user generated list
                if index_1 == index_2:
                    correct += 1
                else:
                    incorrect += 1      
            else:
                pass
            k += 1   
        print("Number of correct digits in correct place:    ", correct)
        print("Number of correct digits not in correct place:", incorrect)
        return False

def run_game():
    """
    TODO: implement Mastermind code here
    """
    
    print("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")
    code_CPU = get_Code()
    turns = 12
    while(True):
        code_user = get_User_Input()
        if (code_Master(code_CPU, code_user)):
            print("Congratulations! You are a codebreaker!")
            break
        else:
            turns -= 1
            print("Turns left:", turns)
            if turns == 0:
                break
        
    print("The code was:", end=' ')
    for item in code_CPU:
        print(item, end='')
    print()
if __name__ == "__main__":
    run_game()
