import unittest
import robot


class MyTestCases(unittest.TestCase):

    #-----------test 1-------------#
    def test_valid_lower1(self):
        self.assertTrue(robot.validate_command("off"))
    
    def test_valid_lower2(self):
        self.assertTrue(robot.validate_command("help"))
    
    def test_invalid_lower3(self):
        self.assertFalse(robot.validate_command("jump up"))
    
    def test_invalid_lower4(self):
        self.assertFalse(robot.validate_command("sleep"))

    def test_valid_upper1(self):
        self.assertTrue(robot.validate_command("OFF"))
    
    def test_valid_upper2(self):
        self.assertTrue(robot.validate_command("HELP"))
    
    def test_invalid_upper3(self):
        self.assertFalse(robot.validate_command("JUMP UP"))
    
    def test_invalid_upper4(self):
        self.assertFalse(robot.validate_command("SLEEP"))
    
    def test_valid_mix1(self):
        self.assertTrue(robot.validate_command("OfF"))
    
    def test_valid_mix2(self):
        self.assertTrue(robot.validate_command("hELp"))
    
    def test_invalid_mix3(self):
        self.assertFalse(robot.validate_command("jUmP uP"))
    
    def test_invalid_mix4(self):
        self.assertFalse(robot.validate_command("SlEeP"))

    #-----------test 2-------------#
    def test_get_commands(self):
        self.assertEqual(robot.help_commands(),  "I can understand these commands:\nOFF  - Shut down robot\nHELP - provide information about commands?\nFORWARD - robot moves forward\nBACK - the robot turns to the right-hand side 90 degrees\nLEFT - the robot turns to the right-hand side 90 degrees\nSPRINT - gives the robot a burst of speed and some extra distance.\n")


    #-----------test 3-------------#
    def test_forward_10_steps(self):
        self.assertEqual(robot.movement("HAL", "10", 'forward'), " > HAL moved forward by 10 steps.")

    def test_forward_5_steps(self):
        self.assertEqual(robot.movement("HAL", "5", 'forward'), " > HAL moved forward by 5 steps.")

    def test_forward_150_steps(self):
        self.assertEqual(robot.movement("HAL", "150", 'forward'), " > HAL moved forward by 150 steps.")

    #-----------test 4-------------#
    def test_track_position1_Forward(self):
        self.assertEqual(robot.track_position('forward', 10), 10)
    
    def test_track_position2_Forward(self):
        self.assertEqual(robot.track_position('forward', 5),  5)

    def test_track_position3_Forward(self):
        self.assertEqual(robot.track_position('forward', 15), 15)
    
    def test_track_position1_Back(self):
        self.assertEqual(robot.track_position('back', 10), -10)
    
    def test_track_position2_Back(self):
        self.assertEqual(robot.track_position('back', 5), -5)

    def test_track_position3_Back(self):
        self.assertEqual(robot.track_position('back', 15), -15)

    #-----------test 5-------------#

    def test_right_turn_lower(self):
        self.assertEqual(robot.turn_movement("HAL", "right"), " > HAL turned right.")

    def test_right_turn_mixed(self):
        self.assertEqual(robot.turn_movement("HAL", "rIgHT"), " > HAL turned right.")
    
    def test_right_turn_upper(self):
        self.assertEqual(robot.turn_movement("HAL", "RIGHT"), " > HAL turned right.")

    def test_left_turn_lower(self):
        self.assertEqual(robot.turn_movement("HAL", "left"), " > HAL turned left.")

    def test_left_turn_mixed(self):
        self.assertEqual(robot.turn_movement("HAL", "lEfT"), " > HAL turned left.")
    
    def test_left_turn_upper(self):
        self.assertEqual(robot.turn_movement("HAL", "LEFT"), " > HAL turned left.")

    #-----------test 6-------------#

    def test_valid_range_X(self):
        self.assertTrue(robot.is_valid_range_X(10))
    
    def test_invalid_range_X(self):
        self.assertFalse(robot.is_valid_range_X(200))
    
    def test_valid_range_Y(self):
        self.assertTrue(robot.is_valid_range_X(10))
    
    def test_invalid_range_Y(self):
        self.assertFalse(robot.is_valid_range_X(200))

    #-----------test 7-------------#

    def test_sprint_command_5_steps(self):
        self.assertEqual(robot.get_sprint_command(5, "HAL"), 15)
    
    def test_sprint_command_10_steps(self):
        self.assertEqual(robot.get_sprint_command(10, "HAL"), 55)
    
    def test_sprint_command_15_steps(self):
        self.assertEqual(robot.get_sprint_command(15, "HAL"), 120)
if __name__ == "__main__":
    unittest.main()