def get_robot_name():
    """
        This fucture gets the name of
        the robot from the user
    """
    name = input("What do you want to name your robot? ")
    while (len(name) == 0):
        name = input("What do you want to name your robot? ")
    return (name)


def get_user_input(name):
    """Prompts user for commands"""
    print(f"{name}: ", end='')
    return (input("What must I do next? "))


def greet_user(name):
    """
        Displays a greeting message
        to the user.
    """
    print(f"{name}: Hello kiddo!")
  

def end_message(name):
    """
        Displays a message when the user
        enters 'off'
    """
    print(f"{name}: Shutting down..")


def help_commands():
    """All the commands the robot can understand"""
    return ("I can understand these commands:\nOFF  - Shut down robot\nHELP - provide information about commands?\nFORWARD - robot moves forward\nBACK - the robot turns to the right-hand side 90 degrees\nLEFT - the robot turns to the right-hand side 90 degrees\nSPRINT - gives the robot a burst of speed and some extra distance.\n")


def print_commands():
    """Prints all the commands to the user"""
    print(help_commands())


def movement(name, steps, direction):

    if (steps == ''):
        steps = '0'
    return (f" > {name} moved {direction} by {steps} steps.")


def turn_movement(name, direction):
    direction = direction.lower()
    return (f" > {name} turned {direction}.")


def split_commands(command):
    """
        This is reponsible for splitting
        movement commmands e.g forward 10
        to forward
    """
    index = command.find(' ')
    return (index)


def validate_command(command):
    """This function checks if a command
        is valid and return True if it is
    """
    command_list = ['off', 'help', 'forward', 'back', 'left', 'right', 'sprint']
    command = command.lower()
    if command in command_list:
        return (True)
    else:
        return (False)


def track_position(command, steps):
    y = 0
    if (command == "forward"):
        y = y + int(steps)
        return (y)
    elif (command == 'back'):
        y = y - int(steps)
        return (y)


def keep_track_turn_position(steps):
    x = 0
    x = x - int(steps)
    return (x)


def print_position(name, x, y):
    print(f" > {name} now at position ({x},{y}).")


def is_valid_range_X(x):

    if (x > -100 and x < 100):
        return (True)
    else:
        return (False)


def is_valid_range_Y(y):

    if (y > -200 and y < 200):
        return (True)
    else:
        return (False)


def invalid_range_message(name):
    return (f"{name}: Sorry, I cannot go outside my safe zone.")


def get_sprint_command(steps, name):

    if (steps <= 0):
        return (0)
    else:
        return steps + get_sprint_command(steps - 1, name)


def print_sprint_steps(steps, name):

    while (steps != 0):
        print(f" > {name} moved forward by {steps} steps.")
        steps -= 1


def do_forward_command(new_X, new_Y, degrees, y, steps):
    
    if (degrees >= 360):
        degrees = degrees - 360
    elif (degrees < 0):
        degrees = 360 + (degrees)

    if (degrees == 0):
        new_X = new_X + 0
        new_Y = new_Y + y
    elif (degrees == 90):
        new_X = new_X + y
        new_Y = new_Y + 0
    elif (degrees == 180):
        x = keep_track_turn_position(steps)
        new_Y = new_Y + x
    elif (degrees == 270):
        new_X = new_X - y
        new_Y = new_Y + 0
    return (new_X, new_Y)


def do_back_command(new_X, new_Y, degrees, y, steps):
    if (degrees >= 360):
        degrees = degrees - 360
    elif (degrees < 0):
        degrees = 360 + (degrees)

    if (degrees == 0):
        new_X = new_X + 0
        new_Y = new_Y + y
    elif (degrees == 90):
        new_X = new_X + y
        new_Y = new_Y + 0
    elif (degrees == 180):
        x = keep_track_turn_position(steps)
        new_Y = new_Y + x
    elif (degrees == 270):
        new_X = new_X - y
        new_Y = new_Y + 0
    return (new_X, new_Y)


def do_sprint_command(name, steps, new_X, new_Y, degrees):
    if (degrees >= 360):
        degrees = degrees - 360
    elif (degrees < 0):
        degrees = degrees + 360

    if (degrees == 0):
        y = get_sprint_command(steps, name)
        new_Y = new_Y + y
    elif (degrees == 90):
        y = get_sprint_command(steps, name)
        new_X = new_X + y
    elif (degrees == 180):
        x = get_sprint_command(steps, name)
        new_Y = new_Y + x
    elif (degrees == 270):
        y = get_sprint_command(steps, name)
        new_X = new_X - y
    print(degrees)
    return (new_X, new_Y)


def get_commands(name, command):
    
    invalid_com = command
    command = command.lower()
    position = (0, 0)
    new_X = 0
    new_Y = 0
    degrees = 0
    
    while(command != "off"):
        index = split_commands(command)
        temp_val_x = 0
        temp_val_y = 0
        if (index == -1):           #if the index is -1 that means there is not space in a command e.g help, off and etc.
            if (validate_command(command)):
                if (command == "help"):
                    print_commands()
                elif (command == "right"):
                    degrees += 90
                    print(turn_movement(name, command.lower()))
                    print_position(name, new_X, new_Y)
                elif (command == "left"):
                    degrees -= 90
                    print(turn_movement(name, command.lower()))
                    print_position(name, new_X, new_Y)
                   
            else:
                print(f"{name}: Sorry, I did not understand '{invalid_com}'.")

        elif (index >= 0):          #if the index is zero or greater, than the command has a space e.g forward 10, backward 5 and etc.
            if (validate_command(command[:index])):
                if (command[:index] == 'forward' and (command[index + 1:].isdigit() == True)):
                    steps = command[index + 1: ]
                    (y) = track_position(command[:index], steps)
                    temp_val_x = new_X
                    temp_val_y = new_Y
                    (new_X, new_Y) = do_forward_command(new_X, new_Y, degrees, y, steps)

                    if (is_valid_range_X(new_X) and is_valid_range_Y(new_Y)):
                        print(movement(name, steps, command[:index].lower()))
                        print_position(name, new_X, new_Y)
                    else:
                        print(invalid_range_message(name))
                        new_X = temp_val_x
                        new_Y = temp_val_y
                        print_position(name, new_X, new_Y)

                elif (command[:index] == 'back' and (command[index + 1:].isdigit() == True)):
                    steps = command[index + 1: ]
                    (y) = track_position(command[:index], steps)
                    (new_X, new_Y) = do_back_command(new_X, new_Y, degrees, y, steps)

                    if (is_valid_range_X(new_X) and is_valid_range_Y(new_Y)):
                        print(movement(name, steps, command[:index].lower()))
                        print_position(name, new_X, new_Y)
                    else:
                        print(invalid_range_message(name))
                        new_X = temp_val_x
                        new_Y = temp_val_y
                        print_position(name, new_X, new_Y)

                elif (command[:index] == 'sprint' and (command[index + 1:].isdigit() == True)):
                    steps = int(command[index + 1: ])
                    temp_val_x = new_X
                    temp_val_y = new_Y
                    if (steps >= 20):
                        print(invalid_range_message(name))
                        steps = 0
                    else:
                        (new_X, new_Y) = do_sprint_command(name, steps, new_X, new_Y, degrees)

                        if (is_valid_range_X(new_X) and is_valid_range_Y(new_Y)):
                            print_sprint_steps(steps, name)
                            print_position(name, new_X, new_Y)
                        else:
                            print(invalid_range_message(name))
                            new_X = temp_val_x
                            new_Y = temp_val_y
            else:
                print(f"{name}: Sorry, I did not understand '{invalid_com}'.")

        position = (new_X, new_Y)
        command = get_user_input(name)
        command = command.lower()
    end_message(name)


def robot_start():
    """This is the entry function, do not change"""
    name = get_robot_name()
    greet_user(name)
    command = get_user_input(name)
    get_commands(name, command)


if __name__ == "__main__":
    robot_start()
