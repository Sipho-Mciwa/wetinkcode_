import unittest
from io import StringIO
import sys
from test_base import captured_io
from test_base import run_unittests
import mastermind

random_index = 0


def mock_next_random_int():
    global random_index

    random_index += 1
    if random_index == 1:
        return 1
    elif random_index == 2:
        return 2
    elif random_index == 3:
        return 3
    else:
        return 4


class MyTestCase(unittest.TestCase):

    def test_correct(self):
        global random_index
        random_index = 0
        pref_random = mastermind.random.randint
        mastermind.random.randint = lambda a, b: mock_next_random_int()

        with captured_io(StringIO('1234\n')) as (out, err):
            mastermind.run_game()

        mastermind.random.randint = pref_random
        output = out.getvalue().strip()
        self.assertEqual("""4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.
Input 4 digit code: Number of correct digits in correct place:     4
Number of correct digits not in correct place: 0
Congratulations! You are a codebreaker!
The code was: [1, 2, 3, 4]""", output)

    def test_too_long(self):
        global random_index
        random_index = 0
        pref_random = mastermind.random.randint
        mastermind.random.randint = lambda a, b: mock_next_random_int()

        with captured_io(StringIO('12345\n1234\n')) as (out, err):
            mastermind.run_game()

        mastermind.random.randint = pref_random
        output = out.getvalue().strip()
        self.assertEqual("""4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.
Input 4 digit code: Please enter exactly 4 digits.
Input 4 digit code: Number of correct digits in correct place:     4
Number of correct digits not in correct place: 0
Congratulations! You are a codebreaker!
The code was: [1, 2, 3, 4]""", output)

    def test_too_short(self):
        global random_index
        random_index = 0
        pref_random = mastermind.random.randint
        mastermind.random.randint = lambda a, b: mock_next_random_int()

        with captured_io(StringIO('123\n1234\n')) as (out, err):
            mastermind.run_game()

        mastermind.random.randint = pref_random
        output = out.getvalue().strip()
        self.assertEqual("""4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.
Input 4 digit code: Please enter exactly 4 digits.
Input 4 digit code: Number of correct digits in correct place:     4
Number of correct digits not in correct place: 0
Congratulations! You are a codebreaker!
The code was: [1, 2, 3, 4]""", output)

    def test_2_turns(self):
        global random_index
        random_index = 0
        pref_random = mastermind.random.randint
        mastermind.random.randint = lambda a, b: mock_next_random_int()

        with captured_io(StringIO('8888\n1234\n')) as (out, err):
            mastermind.run_game()

        mastermind.random.randint = pref_random
        output = out.getvalue().strip()
        self.assertEqual("""4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.
Input 4 digit code: Number of correct digits in correct place:     0
Number of correct digits not in correct place: 0
Turns left: 11
Input 4 digit code: Number of correct digits in correct place:     4
Number of correct digits not in correct place: 0
Congratulations! You are a codebreaker!
The code was: [1, 2, 3, 4]""", output)

    def test_unittest_exist(self):
        import test_functions
        self.assertTrue('test_functions' in sys.modules, "test_functions module should be found")

    def test_unittest_succeeds(self):
        import test_functions
        test_result = run_unittests("test_functions")
        self.assertTrue(test_result.wasSuccessful(), "unit tests should succeed")


if __name__ == '__main__':
    unittest.main()
