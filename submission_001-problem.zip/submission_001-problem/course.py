

def create_outline():
    """
    TODO: implement your code here
    """
    courses =  set(["Introduction to Python","Tools of the Trade", "How to make decisions", "How to repeat code", "How to structure data", "Functions", "Modules"])
    List_of_problems = ['Problem 1','Problem 2','Problem 3']
    student_Records = [('Nyari', 'Introduction to Python', 'Problem 2', '[STARTED]'), ('Adam', 'How to make decisions', 'Problem 1', '[GRADED]'), ('Sipho', 'How to repeat code', 'Problem 2','[COMPLETED]'), ('Tumi', 'How to structure data', 'Problem 3', '[STARTED]'), ('Linda', 'Tools of the Trade', 'Problem 1', '[GRADED]'), ('Fortune', 'Functions', 'Problem 4', '[COMPLETED]')]
    problems = dict()

    for topics in (courses):
        problems[topics] = List_of_problems

    #Topics
    print("Course Topics:")
    courseTopics = []
    for x in courses:
        courseTopics.append(x)
    courseTopics.sort()

    for k in courseTopics:
        print('*', k)
    
    #problems
    print("Problems:")
    for items in problems:
        i = 0
        list = problems[items]
        print('*', items, end=' : ')
        while (i < len(list)):
            if i < 2:
                print(list[i], end=', ')
            else:
                print(list[i])
            i += 1 
    #student progress
    student_Records = [(index[3],index[2], index[1], index[0]) for index in student_Records]
    student_Records.sort(reverse=True)
    student_Records = [(index[3],index[2], index[1], index[0]) for index in student_Records]
    print("Student Progress:")
    for i in range(len(student_Records)):
        k = 0
        print(str(i + 1) + '.',end='')
        while (k < len(student_Records[i])):
            if k < 3:
                print(student_Records[i][k], end=' - ')
            else:
                print(student_Records[i][k])
            k += 1
    

if __name__ == "__main__":
    create_outline()
